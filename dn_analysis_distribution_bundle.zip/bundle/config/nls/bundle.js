define({
    root:
            {
                bundleName: "Analysis/Distribution Config",
                bundleDescription: "Configuration Bundle for Analysis/Distribution-Bundle",
                windowTitle: "Analysis/Distribution Config",
                description: "Settings for the Analysis/Distribution bundle",
                column: "Column",
                pie: "Pie",
                all: "All",
                extent: "Extent",
                defaultChartType: "Default Chart Type",
                useExtent: "Use Extent",
                enableChartSwitch:  "Enable Chart Switch",
                enableExtentSwitch: "Enable Extent Switch",
                store: "Store"
            },
    de: true
});