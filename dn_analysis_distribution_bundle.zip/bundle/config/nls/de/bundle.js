define({
    bundleName: "Analyse/Verteilung Konfiguration",
    bundleDescription: "Konfigurationsbundle f\u00fcr das Verteilungs-Bundle",
    windowTitle: "Analyse/Verteilung Konfiguration",
    description: "Einstellungen f\u00fcr das Analyse/Verteilung-Bundle",
    column: "Balkendiagramm",
    pie: "Tortendiagramm",
    all: "Alle",
    extent: "Auschnitt",
    defaultChartType: "Standard Diagrammtyp",
    useExtent: "Aktuellen Ausschnitt verwenden",
    enableChartSwitch: "Diagrammtyp-Änderung zulassen",
    enableExtentSwitch: "Verwendung des aktuellen Ausschnitts zulassen",
    store: "Store"
});