define([
    ".",
    "ct/Stateful",
    "wizard/DataFormBuilderWidgetFactory",
    "./StoresStore"
], {});