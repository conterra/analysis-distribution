define({
    bundleName: "Analyse/Verteilung",
    bundleDescription: "Dieses Bundle z\u00e4lt alle Features und stellt die Ergebnisse in Diagrammen dar.",
    toolName: "Analyse/Verteilung-Tool",
    toolTooltip: "Analyse/Verteilung-Tool",
    windowTitle: "Analyse / Verteilung",
    column: "Balkendiagramm",
    pie: "Tortendiagramm",
    all: "Alle",
    extent: "Aktuellen Auschnitt verwenden",
    on: "an",
    off: "aus",
    null: ""
});