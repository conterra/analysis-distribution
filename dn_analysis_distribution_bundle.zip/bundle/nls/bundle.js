define({
    root:
            {
                bundleName: "Analysis/Distribution",
                bundleDescription: "This bundle counts all Features and presents the results in charts",
                toolName: "Analysis/Distribution-Tool",
                toolTooltip: "Analysis/Distribution-Tool",
                windowTitle: "Analysis / Distribution",
                column: "Columnchart",
                pie: "Piechart",
                all: "All",
                extent: "Use Extent",
                on: "on",
                off: "off",
                null: ""
            },
    de: true
});