define([
    ".",
    "./TabWidgetFactory",
    "./ChartingWidgetController",
    "./ChartingWidget",
    "ct/tools/Tool"
], {});